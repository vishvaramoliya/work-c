#include<stdio.h>
int main()
{
	printf("NAME:Vishwa\n");
	printf("AGE:18\n");
	printf("SCHOOL:Tapan School");
}
