#include<stdio.h>
int main()
{
	printf("--------\n");
	printf("|\t|\n");
	printf("R\t|\n");
	printf("N\t|\n");
	printf("W\t|\n");
	printf("|\t|\n");
	printf("--------");	
}
