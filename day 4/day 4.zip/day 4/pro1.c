#include<stdio.h>
void main()
{
    int hr,pay;

    printf("\n Enter the number of hours worked this week:");
        scanf("%d",&hr);

    printf("\n Weekly pay:%d",hr*15);
}