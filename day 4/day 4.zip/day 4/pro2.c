#include<stdio.h>
void main()
{
    float pi=3.14159,r;

    printf("\n Enter the number of redis ");
        scanf("%f",&r);

    printf("\n circumference circle :%f",2*pi*r);
}