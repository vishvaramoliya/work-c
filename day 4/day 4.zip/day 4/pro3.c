#include<stdio.h>
void main()
{
    int a,b;

    printf("\n Enter the number of a ");
        scanf("%d",&a);
        printf("\n Enter the number of b ");
        scanf("%d",&b);

    printf("\n product of number :%d",a*b);
}