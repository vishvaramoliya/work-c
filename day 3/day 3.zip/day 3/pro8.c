#include<stdio.h>
void main()
{
	int l=4,ans;

	ans=4*l;

	printf("\n length=%d",l);
	
	printf("\n perimeter of a square is=%d",ans);

}