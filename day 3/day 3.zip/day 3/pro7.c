#include<stdio.h>
void main()
{
	int l=4,w=10,ans;

	ans=2*(l+w);

	printf("\n length=%d",l);
	printf("\n wigth=%d",w);
	printf("\n perimeter of a rectangle is=%d",ans);

}