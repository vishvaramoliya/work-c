#include<stdio.h>
void main()
{
	int a=4,b=10,c=10,d=20,ans;

	ans=a*b*c*d;

	printf("\n First value is=%d",a);
	printf("\n Secound value is=%d",b);
	printf("\n Third value is=%d",c);
	printf("\n Fourth value is=%d",d);

	printf("\n The multiplication of four number is=%d",ans);

}