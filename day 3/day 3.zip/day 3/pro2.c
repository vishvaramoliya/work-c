#include<stdio.h>
void main()
{
	int l=4,ans;

	ans=l*l;

	printf("\n length=%d",l);
	
	printf("\n aera of square=%d",ans);

}