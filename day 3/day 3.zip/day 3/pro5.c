#include<stdio.h>
void main()
{
	int a=4,b=10,c=15,ans;

	ans=a+b+c;

	printf("\n First value is=%d",a);
	printf("\n Secound value is=%d",b);
	printf("\n Third value is=%d",c);
	printf("\n The answer of three number is=%d",ans);

}