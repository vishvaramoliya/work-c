#include<stdio.h>
void main()
{
	int a=2,b=10,ans;

	ans=b/a;

	printf("\n First value is=%d",a);
	printf("\n Secound value is=%d",b);
	
	printf("\n Division=%d",ans);

}