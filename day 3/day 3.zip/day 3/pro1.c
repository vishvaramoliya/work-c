#include<stdio.h>
void main()
{
	int l=4,w=10,ans;

	ans=l*w;

	printf("\n length=%d",l);
	printf("\n wigth=%d",w);
	printf("\n answer=%d",ans);

}