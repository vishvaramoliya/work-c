#include<stdio.h>
void main()
{
	int a=4,b=10,ans;

	ans=a+b;

	printf("\n First value is=%d",a);
	printf("\n Secound value is=%d",b);
	
	printf("\n aera of square=%d",ans);

}